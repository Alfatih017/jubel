const AccountModel = require('../models/Account');

class AccountController {
  static async createAccount(req, res) {
    // Implementasi
  }

  static async getAccounts(req, res) {
    // Implementasi
  }

  static async updateAccount(req, res) {
    // Implementasi
  }

  static async deleteAccount(req, res) {
    // Implementasi
  }
}

module.exports = AccountController;