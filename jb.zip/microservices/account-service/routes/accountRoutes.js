const express = require('express');
const router = express.Router();
const AccountController = require('../controllers/AccountController');

router.post('/', AccountController.createAccount);
router.get('/', AccountController.getAccounts);
router.put('/:id', AccountController.updateAccount);
router.delete('/:id', AccountController.deleteAccount);

module.exports = router;