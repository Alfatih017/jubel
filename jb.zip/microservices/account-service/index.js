const express = require('express');
const { connectDatabase } = require('./database');
const accountRoutes = require('./routes/accountRoutes');

const app = express();
app.use(express.json());

async function startService() {
  await connectDatabase();
  
  app.use('/accounts', accountRoutes);

  const PORT = process.env.ACCOUNT_SERVICE_PORT || 3001;
  app.listen(PORT, () => {
    console.log(`Account service listening on port ${PORT}`);
  });
}