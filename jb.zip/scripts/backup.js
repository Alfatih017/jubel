// scripts/backup.js

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const backupDir = path.resolve(__dirname, '../backups');
const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
const backupFile = path.join(backupDir, `backup-${timestamp}.sql`);

if (!fs.existsSync(backupDir)){
    fs.mkdirSync(backupDir);
}

const databaseUrl = new URL(process.env.DATABASE_URL);
const command = `pg_dump -h ${databaseUrl.hostname} -p ${databaseUrl.port} -U ${databaseUrl.username} -F p ${databaseUrl.pathname.substr(1)} > ${backupFile}`;

exec(command, (error, stdout, stderr) => {
    if (error) {
        console.error(`Error: ${error.message}`);
        return;
    }
    if (stderr) {
        console.error(`Stderr: ${stderr}`);
        return;
    }
    console.log(`Backup created successfully: ${backupFile}`);
});