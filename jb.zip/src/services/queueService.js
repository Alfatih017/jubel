// src/services/queueService.js

const amqp = require('amqplib');
const logger = require('../utils/logger');

class QueueService {
  constructor() {
    this.connection = null;
    this.channel = null;
  }

  async connect() {
    try {
      this.connection = await amqp.connect(process.env.RABBITMQ_URL);
      this.channel = await this.connection.createChannel();
      logger.info('Connected to RabbitMQ');
    } catch (error) {
      logger.error('Error connecting to RabbitMQ:', error);
      throw error;
    }
  }

  async assertQueue(queue) {
    if (!this.channel) {
      await this.connect();
    }
    await this.channel.assertQueue(queue, { durable: true });
  }

  async sendToQueue(queue, message) {
    if (!this.channel) {
      await this.connect();
    }
    this.channel.sendToQueue(queue, Buffer.from(message), { persistent: true });
  }

  async consume(queue, callback) {
    if (!this.channel) {
      await this.connect();
    }
    await this.channel.consume(queue, callback);
  }

  ack(message) {
    this.channel.ack(message);
  }

  async close() {
    if (this.channel) {
      await this.channel.close();
    }
    if (this.connection) {
      await this.connection.close();
    }
    logger.info('Closed RabbitMQ connection');
  }
}

module.exports = new QueueService();