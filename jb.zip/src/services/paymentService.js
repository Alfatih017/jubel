const axios = require('axios');
const crypto = require('crypto');
const Payment = require('../models/Payment');
const logger = require('../utils/logger');

class PaymentService {
  constructor() {
    this.apiKey = process.env.PAYMENT_GATEWAY_API_KEY;
    this.apiSecret = process.env.PAYMENT_GATEWAY_API_SECRET;
    this.baseUrl = process.env.PAYMENT_GATEWAY_BASE_URL;
  }

  async createPayment(userId, amount, currency = 'USD') {
    try {
      const paymentData = {
        amount,
        currency,
        user_id: userId,
        timestamp: Date.now(),
      };

      const signature = this.generateSignature(paymentData);

      const response = await axios.post(`${this.baseUrl}/create-payment`, {
        ...paymentData,
        signature,
      }, {
        headers: { 'Authorization': `Bearer ${this.apiKey}` }
      });

      const payment = await Payment.create({
        userId,
        amount,
        currency,
        paymentGatewayId: response.data.payment_id,
        status: 'pending',
      });

      return payment;
    } catch (error) {
      logger.error('Error creating payment', error);
      throw new Error('Payment creation failed');
    }
  }

  async verifyPayment(paymentId) {
    try {
      const payment = await Payment.findOne({ where: { paymentGatewayId: paymentId } });

      if (!payment) {
        throw new Error('Payment not found');
      }

      const response = await axios.get(`${this.baseUrl}/verify-payment/${paymentId}`, {
        headers: { 'Authorization': `Bearer ${this.apiKey}` }
      });

      if (response.data.status === 'completed') {
        payment.status = 'completed';
        await payment.save();
      }

      return payment;
    } catch (error) {
      logger.error('Error verifying payment', error);
      throw new Error('Payment verification failed');
    }
  }

  generateSignature(data) {
    const signatureString = Object.keys(data)
      .sort()
      .map(key => `${key}=${data[key]}`)
      .join('&');

    return crypto.createHmac('sha256', this.apiSecret)
      .update(signatureString)
      .digest('hex');
  }
}

module.exports = new PaymentService();