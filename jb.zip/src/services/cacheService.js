const Redis = require('ioredis');
const logger = require('../utils/logger');

class CacheService {
  constructor() {
    this.client = new Redis(process.env.REDIS_URL);
    this.client.on('error', (err) => logger.error('Redis Client Error', err));
  }

  async get(key) {
    try {
      const value = await this.client.get(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      logger.error('Error getting cache', error);
      return null;
    }
  }

  async set(key, value, expirationInSeconds = 3600) {
    try {
      await this.client.set(key, JSON.stringify(value), 'EX', expirationInSeconds);
    } catch (error) {
      logger.error('Error setting cache', error);
    }
  }

  async del(key) {
    try {
      await this.client.del(key);
    } catch (error) {
      logger.error('Error deleting cache', error);
    }
  }
}

module.exports = new CacheService();