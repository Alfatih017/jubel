// src/services/notificationService.js

const TelegramBot = require('node-telegram-bot-api');
const logger = require('../utils/logger');
const queueService = require('./queueService');

class NotificationService {
  constructor(botToken) {
    this.bot = new TelegramBot(botToken);
    this.queueName = 'notifications';
  }

  async initialize() {
    await queueService.assertQueue(this.queueName);
    this.consumeNotifications();
  }

  async sendNotification(userId, message) {
    try {
      await this.bot.sendMessage(userId, message);
      logger.info(`Notification sent to user ${userId}`);
    } catch (error) {
      logger.error(`Error sending notification to user ${userId}: ${error}`);
    }
  }

  async queueNotification(userId, message) {
    const notification = { userId, message };
    await queueService.sendToQueue(this.queueName, JSON.stringify(notification));
    logger.info(`Notification queued for user ${userId}`);
  }

  async consumeNotifications() {
    await queueService.consume(this.queueName, async (msg) => {
      if (msg !== null) {
        const { userId, message } = JSON.parse(msg.content.toString());
        await this.sendNotification(userId, message);
        queueService.ack(msg);
      }
    });
    logger.info('Started consuming notifications from queue');
  }

  async broadcastNotification(userIds, message) {
    for (const userId of userIds) {
      await this.queueNotification(userId, message);
    }
    logger.info(`Broadcast notification queued for ${userIds.length} users`);
  }
}

module.exports = new NotificationService(process.env.TELEGRAM_BOT_TOKEN);