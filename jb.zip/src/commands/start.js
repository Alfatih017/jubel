// src/commands/start.js

const { createNewUser } = require('../database/models/User');
const logger = require('../utils/logger');

module.exports = (bot) => {
  bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username;

    try {
      // Cek apakah user sudah ada di database
      let user = await createNewUser(userId, username);
      
      const welcomeMessage = `Selamat datang di Bot Manajemen Akun! 🎉\n\n`
        + `Saya di sini untuk membantu Anda mengelola akun dengan mudah.\n\n`
        + `Berikut adalah beberapa perintah yang tersedia:\n`
        + `/help - Melihat daftar perintah lengkap\n`
        + `/account - Mengelola akun Anda\n`
        + `/payment - Informasi pembayaran\n\n`
        + `Jika Anda memerlukan bantuan, jangan ragu untuk menghubungi tim dukungan kami.`;

      await bot.sendMessage(chatId, welcomeMessage);
      logger.info(`New user started the bot: ${username} (${userId})`);
    } catch (error) {
      logger.error(`Error in start command: ${error}`);
      await bot.sendMessage(chatId, 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.');
    }
  });
};