// src/commands/admin.js

const logger = require('../utils/logger');
const { isAdmin } = require('../middlewares/authMiddleware');

module.exports = (bot) => {
  bot.onText(/\/admin/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    try {
      if (!await isAdmin(userId)) {
        await bot.sendMessage(chatId, 'Maaf, Anda tidak memiliki akses ke perintah ini.');
        logger.warn(`Non-admin user ${userId} attempted to use admin command`);
        return;
      }

      const adminMessage = `Selamat datang, Admin! 👑\n\n`
        + `Berikut adalah perintah khusus admin:\n`
        + `/stats - Melihat statistik bot\n`
        + `/broadcast - Mengirim pesan broadcast ke semua pengguna\n`
        + `/ban - Melarang pengguna menggunakan bot\n`
        + `/unban - Membuka larangan pengguna\n`
        + `/config - Mengubah konfigurasi bot\n\n`
        + `Untuk menggunakan perintah ini, ketik perintah diikuti dengan parameter yang diperlukan.\n`
        + `Contoh: /ban 123456789`;

      await bot.sendMessage(chatId, adminMessage);
      logger.info(`Admin command used by admin ${userId}`);
    } catch (error) {
      logger.error(`Error in admin command: ${error}`);
      await bot.sendMessage(chatId, 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.');
    }
  });

  // Implementasi perintah admin lainnya bisa ditambahkan di sini
};