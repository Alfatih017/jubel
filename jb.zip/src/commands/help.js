// src/commands/help.js

const logger = require('../utils/logger');

module.exports = (bot) => {
  bot.onText(/\/help/, async (msg) => {
    const chatId = msg.chat.id;

    try {
      const helpMessage = `Berikut adalah daftar perintah yang tersedia:\n\n`
        + `/start - Memulai bot dan melihat pesan selamat datang\n`
        + `/help - Menampilkan daftar perintah ini\n`
        + `/account - Mengelola akun Anda\n`
        + `/deposit - Menyetor akun baru\n`
        + `/list - Melihat daftar akun Anda\n`
        + `/generate - Menghasilkan akun baru\n`
        + `/update - Memperbarui status akun\n`
        + `/delete - Menghapus akun\n`
        + `/payment - Informasi pembayaran\n\n`
        + `Untuk informasi lebih lanjut tentang setiap perintah, ketik perintah diikuti dengan "info".\n`
        + `Contoh: /account info`;

      await bot.sendMessage(chatId, helpMessage);
      logger.info(`Help command used by user ${msg.from.id}`);
    } catch (error) {
      logger.error(`Error in help command: ${error}`);
      await bot.sendMessage(chatId, 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.');
    }
  });
};