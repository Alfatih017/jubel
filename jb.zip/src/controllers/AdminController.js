// src/controllers/AdminController.js

const User = require('../database/models/User');
const Account = require('../database/models/Account');
const notificationService = require('../services/notificationService');
const logger = require('../utils/logger');

class AdminController {
  static async getStats(req, res) {
    try {
      const userCount = await User.count();
      const accountCount = await Account.count();
      const activeAccountCount = await Account.count({ where: { status: 'active' } });

      res.json({
        users: userCount,
        accounts: accountCount,
        activeAccounts: activeAccountCount
      });
    } catch (error) {
      logger.error('Error getting stats:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async getUsers(req, res) {
    try {
      const users = await User.findAll({
        attributes: ['id', 'username', 'createdAt'],
        limit: 100,
        order: [['createdAt', 'DESC']]
      });

      res.json(users);
    } catch (error) {
      logger.error('Error getting users:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async getAccounts(req, res) {
    try {
      const accounts = await Account.findAll({
        attributes: ['id', 'userId', 'username', 'type', 'status', 'createdAt'],
        limit: 100,
        order: [['createdAt', 'DESC']]
      });

      res.json(accounts);
    } catch (error) {
      logger.error('Error getting accounts:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async broadcastMessage(req, res) {
    const { message } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    try {
      const users = await User.findAll({ attributes: ['id'] });
      const userIds = users.map(user => user.id);

      await notificationService.broadcastNotification(userIds, message);

      res.json({ message: 'Broadcast sent successfully' });
    } catch (error) {
      logger.error('Error broadcasting message:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async banUser(req, res) {
    const { userId } = req.params;

    try {
      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      user.isBanned = true;
      await user.save();

      res.json({ message: 'User banned successfully' });
    } catch (error) {
      logger.error('Error banning user:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async unbanUser(req, res) {
    const { userId } = req.params;

    try {
      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      user.isBanned = false;
      await user.save();

      res.json({ message: 'User unbanned successfully' });
    } catch (error) {
      logger.error('Error unbanning user:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
}

module.exports = AdminController;