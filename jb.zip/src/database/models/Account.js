// src/database/models/Account.js

const { Model, DataTypes } = require('sequelize');
const sequelize = require('../index');

class Account extends Model {}

Account.init({
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  username: {
    type: DataTypes.STRING,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
  type: {
    type: DataTypes.ENUM('Cube', 'Lainnya'),
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive', 'suspended'),
    defaultValue: 'active'
  },
  lastUsed: {
    type: DataTypes.DATE
  }
}, {
  sequelize,
  modelName: 'Account',
  timestamps: true
});

module.exports = Account;