// src/middlewares/authMiddleware.js

const User = require('../database/models/User');
const logger = require('../utils/logger');

async function isAdmin(req, res, next) {
  const apiKey = req.headers['x-api-key'];

  if (!apiKey) {
    return res.status(401).json({ error: 'API key is required' });
  }

  try {
    const user = await User.findOne({ where: { apiKey, isAdmin: true } });

    if (!user) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    req.user = user;
    next();
  } catch (error) {
    logger.error('Error in admin authentication:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

module.exports = { isAdmin };