// src/routes/adminRoutes.js

const express = require('express');
const router = express.Router();
const AdminController = require('../controllers/AdminController');
const authMiddleware = require('../middlewares/authMiddleware');

router.use(authMiddleware.isAdmin);

router.get('/stats', AdminController.getStats);
router.get('/users', AdminController.getUsers);
router.get('/accounts', AdminController.getAccounts);
router.post('/broadcast', AdminController.broadcastMessage);
router.post('/ban/:userId', AdminController.banUser);
router.post('/unban/:userId', AdminController.unbanUser);

module.exports = router;