const express = require('express');
const router = express.Router();
const AnalyticsController = require('../controllers/AnalyticsController');
const authMiddleware = require('../middlewares/authMiddleware');

router.get('/user-growth', authMiddleware, AnalyticsController.getUserGrowth);
router.get('/account-stats', authMiddleware, AnalyticsController.getAccountStats);
router.get('/payment-summary', authMiddleware, AnalyticsController.getPaymentSummary);

module.exports = router;