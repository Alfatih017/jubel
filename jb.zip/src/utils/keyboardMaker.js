// src/utils/keyboardMaker.js

function createKeyboard(buttons) {
  return {
    keyboard: buttons,
    resize_keyboard: true,
    one_time_keyboard: true
  };
}

function createInlineKeyboard(buttons) {
  return {
    inline_keyboard: buttons.map(row => 
      row.map(button => (
        typeof button === 'string' 
          ? { text: button, callback_data: button }
          : { text: button.text, callback_data: button.callback_data }
      ))
    )
  };
}

module.exports = { createKeyboard, createInlineKeyboard };