// src/index.js

require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const TelegramBot = require('node-telegram-bot-api');
const { setupWebhook, setupLongPolling } = require('./config/bot');
const { connectDatabase } = require('./database');
const { setupRedis } = require('./services/cacheService');
const { connect: connectQueue } = require('./services/queueService');
const notificationService = require('./services/notificationService');
const adminRoutes = require('./routes/adminRoutes');
const logger = require('./utils/logger');

const app = express();
app.use(bodyParser.json());

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const PORT = process.env.PORT || 3000;
const URL = process.env.WEBHOOK_URL;

async function startBot() {
  try {
    // Inisialisasi bot
    const bot = new TelegramBot(TOKEN);

    // Koneksi ke database
    await connectDatabase();

    // Setup Redis
    await setupRedis();

    // Setup RabbitMQ
    await connectQueue();

    // Inisialisasi Notification Service
    await notificationService.initialize();

    // Pilih mode: webhook atau long polling
    if (process.env.USE_WEBHOOK === 'true') {
      await setupWebhook(bot, app, URL, PORT);
    } else {
      await setupLongPolling(bot);
    }

    // Setup command handlers
    require('./commands/start')(bot);
    require('./commands/help')(bot);
    require('./commands/admin')(bot);

    // Setup message handlers
    require('./handlers/accountHandler')(bot);
    require('./handlers/adminHandler')(bot);
    require('./handlers/paymentHandler')(bot);
    require('./handlers/userHandler')(bot);

    // Setup admin routes
    app.use('/admin', adminRoutes);

    logger.info('Bot started successfully');
  } catch (error) {
    logger.error('Error starting bot:', error);
    process.exit(1);
  }
}

startBot();

module.exports = app;