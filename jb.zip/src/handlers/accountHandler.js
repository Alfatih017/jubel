// src/handlers/accountHandler.js

const Account = require('../database/models/Account');
const logger = require('../utils/logger');
const { createKeyboard, createInlineKeyboard } = require('../utils/keyboardMaker');
const cacheService = require('../services/cacheService');
const notificationService = require('../services/notificationService');

module.exports = (bot) => {
  // ... (kode sebelumnya tetap sama)

  // Handler untuk perintah update
  bot.onText(/\/update/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    try {
      const accounts = await Account.findAll({ where: { userId } });
      if (accounts.length === 0) {
        await bot.sendMessage(chatId, 'Anda belum memiliki akun yang terdaftar.');
        return;
      }

      let keyboard = accounts.map(account => [{
        text: `${account.username} (${account.type})`,
        callback_data: `update_${account.id}`
      }]);
      keyboard = createInlineKeyboard(keyboard);

      await bot.sendMessage(chatId, 'Pilih akun yang ingin Anda update:', {
        reply_markup: keyboard
      });
    } catch (error) {
      logger.error(`Error in update command: ${error}`);
      await bot.sendMessage(chatId, 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.');
    }
  });

  // Handler untuk callback query (untuk menangani pilihan dari inline keyboard)
  bot.on('callback_query', async (callbackQuery) => {
    const action = callbackQuery.data;
    const msg = callbackQuery.message;
    const chatId = msg.chat.id;
    const userId = callbackQuery.from.id;

    if (action.startsWith('update_')) {
      const accountId = action.split('_')[1];
      const account = await Account.findByPk(accountId);
      
      if (!account) {
        await bot.answerCallbackQuery(callbackQuery.id, { text: 'Akun tidak ditemukan.' });
        return;
      }

      const statusKeyboard = createInlineKeyboard([
        [{ text: 'Aktif', callback_data: `status_${accountId}_active` }],
        [{ text: 'Tidak Aktif', callback_data: `status_${accountId}_inactive` }],
        [{ text: 'Suspended', callback_data: `status_${accountId}_suspended` }]
      ]);

      await bot.sendMessage(chatId, `Pilih status baru untuk akun ${account.username}:`, {
        reply_markup: statusKeyboard
      });
    } else if (action.startsWith('status_')) {
      const [_, accountId, newStatus] = action.split('_');
      const account = await Account.findByPk(accountId);
      
      if (!account) {
        await bot.answerCallbackQuery(callbackQuery.id, { text: 'Akun tidak ditemukan.' });
        return;
      }

      account.status = newStatus;
      await account.save();

      await bot.answerCallbackQuery(callbackQuery.id, { text: 'Status akun berhasil diperbarui.' });
      await bot.sendMessage(chatId, `Status akun ${account.username} telah diubah menjadi ${newStatus}.`);

      // Kirim notifikasi ke pengguna
      await notificationService.sendNotification(userId, `Status akun ${account.username} Anda telah diubah menjadi ${newStatus}.`);
    }
  });
};
  // Handler untuk perintah deposit
  bot.onText(/\/deposit/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    try {
      await bot.sendMessage(chatId, 'Silakan masukkan detail akun yang ingin Anda setorkan:');
      // Simpan state user untuk menunggu input akun
      // Implementasi state management bisa menggunakan Redis atau memory store
    } catch (error) {
      logger.error(`Error in deposit command: ${error}`);
      await bot.sendMessage(chatId, 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.');
    }
  });

  // Handler untuk perintah list
  bot.onText(/\/list/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    try {
      const accounts = await Account.findAll({ where: { userId } });
      if (accounts.length === 0) {
        await bot.sendMessage(chatId, 'Anda belum memiliki akun yang terdaftar.');
        return;
      }

      let accountList = 'Daftar akun Anda:\n\n';
      accounts.forEach((account, index) => {
        accountList += `${index + 1}. ${account.username} (${account.type}) - Status: ${account.status}\n`;
      });

      await bot.sendMessage(chatId, accountList);
    } catch (error) {
      logger.error(`Error in list command: ${error}`);
      await bot.sendMessage(chatId, 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.');
    }
  });

  // Handler untuk perintah generate
  bot.onText(/\/generate/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    try {
      const keyboard = createKeyboard([
        ['Cube', 'Lainnya']
      ]);

      await bot.sendMessage(chatId, 'Pilih tipe akun yang ingin Anda generate:', {
        reply_markup: keyboard
      });
      // Simpan state user untuk menunggu pilihan tipe akun
    } catch (error) {
      logger.error(`Error in generate command: ${error}`);
      await bot.sendMessage(chatId, 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.');
    }
  });

  // Handler untuk perintah update
  bot.onText(/\/update/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    try {
      const accounts = await Account.findAll({ where: { userId } });
      if (accounts.length === 0) {
        await bot.sendMessage(chatId, 'Anda belum memiliki akun yang terdaftar.');
        return;
      }

      let keyboard = accounts.map(account => [`${account.username} (${account.type})`]);
      keyboard = createKeyboard(keyboard);

      await bot.sendMessage(chatId, 'Pilih akun yang ingin Anda update:', {
        reply_markup: keyboard
      });
      // Simpan state user untuk menunggu pilihan akun
    } catch (error) {
      logger.error(`Error in update command: ${error}`);
      await bot.sendMessage(chatId, 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.');
    }
  });

  // Handler untuk perintah delete
  bot.onText(/\/delete/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    try {
      const accounts = await Account.findAll({ where: { userId } });
      if (accounts.length === 0) {
        await bot.sendMessage(chatId, 'Anda belum memiliki akun yang terdaftar.');
        return;
      }

      let keyboard = accounts.map(account => [`${account.username} (${account.type})`]);
      keyboard = createKeyboard(keyboard);

      await bot.sendMessage(chatId, 'Pilih akun yang ingin Anda hapus:', {
        reply_markup: keyboard
      });
      // Simpan state user untuk menunggu pilihan akun
    } catch (error) {
      logger.error(`Error in delete command: ${error}`);
      await bot.sendMessage(chatId, 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.');
    }
  });

  // Handler untuk callback query (untuk menangani pilihan dari inline keyboard)
  bot.on('callback_query', async (callbackQuery) => {
    const action = callbackQuery.data;
    const msg = callbackQuery.message;
    const chatId = msg.chat.id;
    const userId = callbackQuery.from.id;

    // Implementasi logika untuk menangani berbagai callback query
    // Misalnya, untuk generate akun, update status, atau menghapus akun
  });
};