// src/config/bot.js

const logger = require('../utils/logger');

async function setupWebhook(bot, app, url, port) {
  const webhookPath = `/bot${bot.token}`;
  await bot.setWebHook(`${url}${webhookPath}`);
  
  app.post(webhookPath, (req, res) => {
    bot.processUpdate(req.body);
    res.sendStatus(200);
  });

  app.listen(port, () => {
    logger.info(`Express server is listening on ${port}`);
  });

  logger.info('Webhook setup completed');
}

async function setupLongPolling(bot) {
  await bot.startPolling();
  logger.info('Long polling started');
}

module.exports = { setupWebhook, setupLongPolling };